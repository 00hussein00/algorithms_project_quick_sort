/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.quicksort;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author user
 */
public class QuickSort {
    
    static int partitionCallCount = 0;
    static int swapCallCount = 0;
    
    /*
     * QuickSort function to sort an array using the first index as the pivot
     */
    static int[] quickSortWithFirstIndex(int[] A, int p, int r) {
        if (p < r) {
            int q = partitionWithFirstIndex(A, p, r);
            quickSortWithFirstIndex(A, p, q - 1);
            quickSortWithFirstIndex(A, q + 1, r);
        }
        return A; 
    }

    /*
     * Partition function that uses the first index as the pivot
     */
    static int partitionWithFirstIndex(int[] A, int p, int r) {
        partitionCallCount++;
        int pivot = p;
        int up = p + 1;
        int down = r;

        while (up <= down) {
            while (up <= r && A[up] <= A[pivot]) up++; //to sort in Descending order modified A[up] <= A[pivot] to A[up] >= A[pivot]
            while (down >= p && A[down] > A[pivot]) down--;//to sort in Descending order modified A[down] > A[pivot] to A[up] < A[pivot]

            if (up < down) {
                swap(A, up, down);
            }
        }

        swap(A, pivot, down);
        return down;
    }
    
    /*
     * QuickSort function to sort an array using the last index as the pivot
     */
    static int[] quickSortWithLastIndex(int[] A, int p, int r) {
        if (p < r) {
            int q = partitionWithLastIndex(A, p, r);
            quickSortWithLastIndex(A, p, q - 1);
            quickSortWithLastIndex(A, q + 1, r);
        }
        return A; 
    }
    
    /*
     * Partition function that uses the last index as the pivot
     */
    static int partitionWithLastIndex(int[] A, int p, int r) {
        partitionCallCount++;
        int pivot = r;
        int up = p;
        int down = r - 1;

        while (up <= down) {
            while (up < r && A[up] < A[pivot]) up++;//to sort in Descending order modified A[up] < A[pivot] to A[up] >= A[pivot]
            while (down >= p && A[down] >= A[pivot]) down--;//to sort in Descending order modified A[down] >= A[pivot] to  A[down] < A[pivot]

            if (up < down) {
                swap(A, up, down);
            }
        }

        swap(A, pivot, up);
        return up;
    }
    
    
/*
 * QuickSort function to sort an array using the Random index as the pivot  
 */ 
     public static int[] quicksortWithRandomIndex(int[] A, int start, int end) {
        if (start < end) {
            int pivotIndex = partitionWithRandomIndex(A, start, end);
            quicksortWithRandomIndex(A, start, pivotIndex - 1);
            quicksortWithRandomIndex(A, pivotIndex + 1, end);
        }
        return A ;
    }

     
/*
 * Partition function that uses the Random index as the pivot
 */
    public static int partitionWithRandomIndex (int[] A, int up, int down) {
        int pivotIndex = getRandomPivot(up, down);
        int pivotValue = A[pivotIndex];
        swap(A, pivotIndex, down);
        int storeIndex = up;
        for (int i = up; i < down ; i++) {
            if (A[i] < pivotValue) { // to sort in Descending order from A[i] < pivotValue to A[i] > pivotValue 
                swap(A, i, storeIndex);
                storeIndex++;
            }
        }
        partitionCallCount++;
        swap(A, storeIndex, down);
        return storeIndex;
    }

    public static int getRandomPivot(int start, int end) {
        Random random = new Random();
        return random.nextInt(end - start) + start;
    }

    
    
    
    /*
     * Function to swap two elements in an array
     */
    static void swap(int[] A, int i, int j) {
        swapCallCount++;
        int temp = A[i];
        A[i] = A[j];
        A[j] = temp;
    }


    
    
    
    
    
     
    
    static int getLastIndex(int[]A){   // return the last index element
        return A.length - 1;
    
    }
    

    public static void main(String[] args) {
        int[] AL = new int[]{1,1,1,2,3,4,5,6,7,8,9,10,20,30,35,40,50,60,66,70,75,80,90,100,569,899};                  //Ascending List
        int[] DL = new int[]{1600,100,99,90,80,70,66,56,50,46,44,40,30,22,20,19,15,5,4,3,2,1};                       //Descending List
        int[] UL = new int[]{100,500,8513,6,5,66,84,989,200,81,3,2,5,13,8,61,35,6,66,5,48,1,7,43};                      //Unordered List
       
        quicksortWithRandomIndex(UL, 0 , getLastIndex(UL));
        System.out.println("Array after sort "+ Arrays.toString(UL));
        System.out.println(" partition Call Count "+ partitionCallCount + " swap Call Count : "+swapCallCount);
       
  
    }
    
    /* 
    
        
      
      Random rand = new Random();
      int[] list = new int[1000000];  // make a list of n index 
      
      for (int i = 0; i < list.length; i++) {   
         list[i] = rand.nextInt();      // create new item and set it into index
         System.out.println(list[i]); // print befor sort 
      }
       
      
       System.out.println("-----------------  ---------------------------------- ----------------- -----------------");
       System.out.println(" -----------------  ------------------------------ -  - - - ");
        System.out.println("-----------------  ---------------------------------- ----------------- -----------------");
 
       quickSortWithLastIndex(list, 0 , getLastIndex(list));

      for (int i = 0; i < list.length; i++) {   // print after sort 
         System.out.println(list[i]);
         }
      
       System.out.println(" partition Call Count "+ partitionCallCount + " swap Call Count : "+swapCallCount);
            
      
    */
}
